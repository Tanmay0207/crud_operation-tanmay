<?php
require 'conn.php';
session_start();


if( !$_SESSION['u_name']){
    header('Location: index.php');
}
?>


<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


</head>
<body>
<!-- navbar -->
<?php require 'nav.php';?>
<!-- navbar -->

<!-- main content -->
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Employees</h2></div>
                <ul class="list-group">
                    <li class="list-group-item"><a href="add_new_employee.php">Add New Employee</a></li>
                    <li class="list-group-item"><a href="dash.php">View all Employees</a></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-9 col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Employees list</h2></div>
                <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Details</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                <?php
                      $sql = "SELECT * FROM employees";
                      $result = mysqli_query($conn,  $sql);
                    
                      if(mysqli_num_rows($result) > 0){
                        while($employees = mysqli_fetch_assoc($result)){ ?>
                          
                      <tr>
                           <td><?php echo $employees['e_id']?></td>
                           <td><?php echo $employees['e_name']?></td> 
                           <td><a href="single_employee.php?e_id=<?php echo $employees['e_id']?>" class="btn btn-block btn-xs btn-info">Details</a></td> 
                           <td><a href="single_employee_edit.php?e_id=<?php echo $employees['e_id']?>" class="btn btn-block btn-xs btn-warning">Edit</a></td>  
                           <td><a href="delete_employee.php?e_id=<?php echo $employees['e_id']?>" class="btn btn-block btn-xs btn-danger">Delete</a></td>  
                      </tr>
                      
                      <?php  }
                      }else{
                        echo " 0 Results";
                      }
                
                
                ?>

                </table>
            <div>
        </div>
    </div>
</div>

<!-- main content -->



    <!-- <p> <a href="logout.php">Log Out</a></p>
    <h3 style="text-align:center; margin:250px auto; font-size:50px;">Welcome <?php echo $_SESSION['u_name']; ?></h3> -->


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>