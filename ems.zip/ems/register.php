<?php require 'conn.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body>


<!-- register -->
<div class="container">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-lg-push-4 col-md-push-4">
            <div class="panel panel-default" style="margin-top:50px;">
            <div style="width:500px;height=500px;margin:100px auto;">
                <div class="panel-heading">
                <h2>Login</h2>
                </div>
                <div class="panel-body">

              
                <form action="" method="POST">
            <div class="form-group">
                <label for="exampleInputEmail1">Email Address</label>
                <input type="email" class="form-control input-sm" name="u_email" id="exampleInputEmail1" aria-describedby="emailHelp" required placeholder="Email">
                
            </div>
            <div class="form-group">
                <label for="exampleInputUserName">User name</label>
                <input type="text" class="form-control input-sm" name="u_name"  id="exampleInputUserName" required placeholder="Username">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control input-sm" name="u_pass"  id="exampleInputPassword1" required placeholder="Password">
            </div>
         
            <input type="submit" class="btn btn-success btn-sm" name="u_reg"  value= "Register">
            <a href="index.php" class="btn btn-primary btn-info btn-sm">Login</a>
        </form>
        </div>
                </div>
            
            </div>
        
        </div>
    </div>
</div>
<!-- register -->


<?php

    if( isset( $_POST['u_reg']) ){
        $u_email = $_POST['u_email'];
        $u_name = $_POST['u_name'];
        $u_pass = md5($_POST['u_pass']);
        
         $sql = "INSERT INTO users (u_email, u_name, u_pass) VALUES ('$u_email', '$u_name', '$u_pass')";       

         if(mysqli_query($conn, $sql)){
             echo"<script>alert('Registered Successfully');</script>";
         }
         else{
             echo"Error: " .$sql . "<br>" . mysqli_error($conn);
         }

        }

?>






    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</body>

</html>
