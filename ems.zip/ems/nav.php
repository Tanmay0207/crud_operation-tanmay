<?php

// session_start();

if( !$_SESSION['u_name']){
    header('Location: index.php');
}

?>

<!-- navbar -->
<nav class="navbar navbar-default">
<div class="container">

  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-home-tab" href="dash.php" role="tab" aria-controls="nav-home" aria-selected="true">Welcome <?php echo $_SESSION['u_name']; ?></a>
    <a class="nav-item nav-link" id="nav-profile-tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
    <a class="nav-item nav-link" id="nav-contact-tab"  href="#nav-contact"role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
  </div>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <ul class="nav navbar-nav navbar-right">
        <li>
            <a href="logout.php">Log out</a>
        </li>
    </ul>
  </div>
</nav>


<div/>