                <?php
                require 'conn.php';
                session_start();


                if( !$_SESSION['u_name']){
                    header('Location: index.php');
                }
                ?>


<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


</head>
<body>
<!-- navbar -->
<?php require 'nav.php';?>
<!-- navbar -->

<!-- main content -->
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Employees</h2></div>
                <ul class="list-group">
                    <li class="list-group-item"><a href="add_new_employee.php">Add New Employee</a></li>
                    <li class="list-group-item"><a href="dash.php">View all Employee</a></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-9 col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Add Employee</h2></div>
                    <div class="panel-body">
                        <form action="" method="POST">


                                    <?php
                                $id = $_GET['e_id'];
                                $sql = "SELECT * FROM employees WHERE e_id='$id'";
                                $result = mysqli_query($conn,  $sql);
                                
                                if(mysqli_num_rows($result) > 0){
                                    while($employees = mysqli_fetch_assoc($result)){ ?>





                            <div class="form-group">
                                <input type="text" class="form-control input-sm" name="e_name" value="<?php echo $employees['e_name']?>" placeholder="Employee Name" required>
                            </div>

                             <div class="form-group">
                                <input type="email" class="form-control input-sm"name="e_email" value="<?php echo $employees['e_email']?>" placeholder="Email" required>
                            </div>

                             <div class="form-group">
                                <input type="tel" class="form-control input-sm" name="e_phone" value="<?php echo $employees['e_phone']?>" placeholder="Phone Number" required>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-sm btn-success" name="e_update" value="Update employee">
                            </div>

                              <?php  }
                          }else{
                         echo " 0 Results";
                         }
                     ?>
                        </form>
                    </div>
            <div>
        </div>
    </div>
</div>
<!-- main content -->

                <?php
                if(isset($_POST['e_update'])){
                    $e_name = $_POST['e_name'];
                    $e_email = $_POST['e_email'];
                    $e_phone = $_POST['e_phone'];


                    $sql = "UPDATE employees SET e_name='$e_name', e_email= '$e_email' , e_phone='$e_phone' WHERE e_id='$id'";

                    if(mysqli_query($conn ,$sql)){
                        //   echo "<script>alert('Data updated successfully.')</script>";
                        header('Location: dash.php');
                    }
                    else{
                        echo "Error updating record. " . mysqli_error($conn);
                    }
                }
                
                
                ?>



    <!-- <p> <a href="logout.php">Log Out</a></p>
    <h3 style="text-align:center; margin:250px auto; font-size:50px;">Welcome <?php echo $_SESSION['u_name']; ?></h3> -->


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>